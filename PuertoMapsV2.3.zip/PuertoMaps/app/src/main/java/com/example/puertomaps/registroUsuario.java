package com.example.puertomaps;

import android.os.Bundle;
import android.widget.Button;
import android.widget.EditText;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import androidx.appcompat.app.AppCompatActivity;
import java.util.HashMap;
import java.util.Map;

public class registroUsuario extends AppCompatActivity {

    private EditText editTextNombre, editTextEmail;
    private Button btnRegistrar;
    private EditText etDireccion, etTelefono, etContrasena;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registro_usuario);
        //registro
        editTextNombre = findViewById(R.id.editTextNombre);
        editTextEmail = findViewById(R.id.editTextEmail);
        btnRegistrar = findViewById(R.id.btnRegistrar);

        etDireccion = findViewById(R.id.editTextAddress);
        etTelefono = findViewById(R.id.editTextPhone);
        etContrasena = findViewById(R.id.editTextPassword);

        //tipo de usuario
        RadioGroup radioGroupTipoUsuario = findViewById(R.id.radioGroupTipoUsuario);
        RadioButton radioButtonLocatario = findViewById(R.id.radioButtonLocatario);
        RadioButton radioButtonUsuario = findViewById(R.id.radioButtonUsuario);


        btnRegistrar.setOnClickListener(v -> {

            String nombre = editTextNombre.getText().toString().trim();
            String email = editTextEmail.getText().toString().trim();
            String direccion = etDireccion.getText().toString().trim();
            String telefono = etTelefono.getText().toString().trim();
            String contrasena = etContrasena.getText().toString().trim();

            //verificar si es locatario o usuario
            String tipoUsuario;
            if (radioButtonLocatario.isChecked()) {
                tipoUsuario = "locatario";
            } else if (radioButtonUsuario.isChecked()) {
                tipoUsuario = "usuario";
            } else {
                Toast.makeText(registroUsuario.this, "Por favor selecciona un tipo de usuario", Toast.LENGTH_SHORT).show();
                return; // Evita el registro si no se selecciona ningún tipo de usuario
            }



            if (nombre.isEmpty() || email.isEmpty() || direccion.isEmpty() || telefono.isEmpty() || contrasena.isEmpty()) {
                Toast.makeText(registroUsuario.this, "Por favor ingresa todos los datos", Toast.LENGTH_SHORT).show();
            } else {
                registrarUsuario(nombre, email, direccion, telefono, contrasena, tipoUsuario);
            }
        });
    }

    private void registrarUsuario(String nombre, String email, String direccion, String telefono, String contrasena, String tipoUsuario) {
        String url = "http://192.168.1.10/registro.php"; // Cambia la IP por la de tu servidor
        RequestQueue queue = Volley.newRequestQueue(this);

        StringRequest postRequest = new StringRequest(Request.Method.POST, url,
                response -> Toast.makeText(registroUsuario.this, "Usuario registrado exitosamente", Toast.LENGTH_SHORT).show(),
                error -> Toast.makeText(registroUsuario.this, "Error: " + error.toString(), Toast.LENGTH_SHORT).show()) {
            @Override
            protected Map<String, String> getParams() {
                Map<String, String> params = new HashMap<>();
                params.put("nombre", nombre);
                params.put("email", email);
                params.put("direccion", direccion);
                params.put("telefono", telefono);
                params.put("contrasena", contrasena);
                params.put("tipoUsuario", tipoUsuario);
                return params;
            }
        };

        queue.add(postRequest);
    }
}
